import java.util.Scanner; //

public class ShipCostCalculator {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in); //

        System.out.print("What is the price of your item? ");

        double itemPrice = in.nextDouble();
        double shippingPrice = 0.0;

        if (itemPrice < 100) {
            shippingPrice = itemPrice * 0.02;
        }

        System.out.println("Shipping Price: " + shippingPrice);
        System.out.println("Total Price: " + (itemPrice + shippingPrice));
    }
}